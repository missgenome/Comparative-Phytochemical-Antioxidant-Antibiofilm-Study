# Comparative Evaluation of Phytochemical Composition, Antioxidant, and Antibiofilm Potential of *Neolamarckia cadamba* and *Nardostachys jatamansi*

### 👩‍🔬 Author
**A. Pranita**  
M.Sc. Biotechnology, Odisha University of Agriculture and Technology (OUAT)

---

### 🧬 Project Overview
This study presents a comparative analysis of *Neolamarckia cadamba* and *Nardostachys jatamansi* methanolic extracts with respect to their phytochemical constituents, antioxidant capacity, and antibiofilm activity.  
The project integrates qualitative screening, enzymatic assays, and microbial inhibition experiments to evaluate the pharmacological potential of both species.

---

### 📖 Abstract
*Neolamarckia cadamba* and *Nardostachys jatamansi* are medicinal plants known for diverse bioactive metabolites.  
In this study, methanolic extracts of both plants were examined for phytochemical content and evaluated through DPPH, FRAP, and catalase assays to determine antioxidant potential.  
Antibiofilm efficacy was tested using a crystal violet microtiter plate method. Results showed that *N. cadamba* exhibited higher antioxidant and biofilm inhibition capacities compared to *N. jatamansi*, suggesting its potential as a natural therapeutic agent.

---

### 📊 Method Summary
- **Extraction:** Methanol extraction via Soxhlet apparatus.  
- **Phytochemical Tests:** Standard qualitative assays for alkaloids, flavonoids, phenols, tannins, and saponins.  
- **Antioxidant Assays:** DPPH, FRAP, and catalase activity.  
- **Antibiofilm Assay:** Microtiter plate method using crystal violet staining.

---

### 🧪 Key Findings
- *N. cadamba* contained more phenolics and flavonoids → stronger antioxidant response.  
- *N. jatamansi* showed moderate activity dominated by alkaloid content.  
- Both plants inhibited biofilm formation, with *N. cadamba* demonstrating higher efficacy.  

---

### 🧩 Discussion Summary
The results highlight the importance of polyphenolic compounds in redox modulation and microbial inhibition.  
Strong antioxidant activity may contribute to antibiofilm mechanisms through oxidative stress reduction.  
The findings validate the ethnopharmacological significance of both plants and support further research into their therapeutic applications.

---

### 📚 Citation
If you use or reference this work, please cite as:
> Pranita, A. (2025). Comparative Evaluation of Phytochemical Composition, Antioxidant, and Antibiofilm Potential of *Neolamarckia cadamba* and *Nardostachys jatamansi*. Odisha University of Agriculture and Technology (OUAT).

---

### 🧾 License
This work is shared under the **Creative Commons Attribution–NonCommercial 4.0 International (CC BY-NC 4.0)** license.  
You are free to share and adapt the material for non-commercial purposes, with appropriate credit to the author.
